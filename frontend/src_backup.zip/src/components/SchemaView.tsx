import { useEffect, useMemo, useRef, useState } from "react";
import type { DepartCumul, Poste } from "../lib/types";
import { zoneOfCommune } from "../lib/types";
import {
  fmtNum,
  ildColor,
  ildLabel,
  regimeOf,
  safeColor,
  typeBlocLabel,
} from "../lib/format";

interface RM6 {
  id: string;
  depart: string | null;
  x: number;
  y?: number;
  nom: string | null;
  label_detecte: string | null;
  commande: string | null;
  a_verifier?: boolean;
  etat?: string | null;
}

interface POPoint {
  id: string;
  x: number;
  y: number;
  etat: string;
}

interface Props {
  postes: Poste[];
  departs: DepartCumul[];
  rm6: RM6[];
  pointsOuverture: POPoint[];
  posteSourceLabel: string;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onEdit: (poste: Poste) => void;
  onReorder?: (items: { id: string; x: number }[]) => void;
  onUpdateRm6?: (id: string, data: Record<string, unknown>) => void;
}

type ToolMode = "pan" | "select";

type DisplayNode = {
  id: string;
  kind: "poste" | "rm6";
  depart: string | null;
  x: number;
  y: number;
  label: string;
  sublabel: string;
  meta: string;
  color: string;
  isAntenna: boolean;
  data: Poste | RM6;
};

const BUS_X = 190;
const START_X = 350;
const X_STEP = 132;
const LANE_Y = 120;
const LANE_GAP = 132;
const ANTENNA_DROP = 70;
const NODE_R = 16;

function truncate(value: string | null | undefined, max = 14) {
  if (!value) return "";
  return value.length > max ? `${value.slice(0, max - 1)}…` : value;
}

function isPoste(node: DisplayNode): node is DisplayNode & { data: Poste } {
  return node.kind === "poste";
}

function isRM6(node: DisplayNode): node is DisplayNode & { data: RM6 } {
  return node.kind === "rm6";
}

function DetailCell({ label, value }: { label: string; value: string | number | null | undefined }) {
  return (
    <div>
      <div style={{ fontSize: 10, color: "#7f93a3", textTransform: "uppercase", letterSpacing: "0.05em" }}>
        {label}
      </div>
      <div style={{ fontSize: 12, fontWeight: 700, marginTop: 2 }}>{value || "—"}</div>
    </div>
  );
}

export function SchemaView({
  postes,
  departs,
  rm6,
  pointsOuverture,
  posteSourceLabel,
  selectedId,
  onSelect,
  onEdit,
  onReorder,
}: Props) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [tool, setTool] = useState<ToolMode>("pan");
  const [editMode, setEditMode] = useState(false);
  const [transform, setTransform] = useState({ x: 0, y: 0, s: 1 });
  const [draggingCanvas, setDraggingCanvas] = useState(false);
  const [dragPosteId, setDragPosteId] = useState<string | null>(null);
  const [hoverId, setHoverId] = useState<string | null>(null);
  const dragStartRef = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);
  const nodeDragRef = useRef<{ id: string; startClientX: number; startNodeX: number } | null>(null);

  const childrenByParent = useMemo(() => {
    const map = new Map<string, Poste[]>();
    postes.forEach((p) => {
      if (!p.antenne_de || p.antenne_de === p.id) return;
      const parentExists = postes.some((x) => x.id === p.antenne_de);
      if (!parentExists) return;
      if (!map.has(p.antenne_de)) map.set(p.antenne_de, []);
      map.get(p.antenne_de)!.push(p);
    });
    return map;
  }, [postes]);

  const rootPostes = useMemo(
    () => postes.filter((p) => !p.antenne_de || p.antenne_de === p.id || !postes.some((x) => x.id === p.antenne_de)),
    [postes],
  );

  const laneMap = useMemo(() => {
    const map = new Map<string, number>();
    departs.forEach((d, i) => map.set(d.depart, LANE_Y + i * LANE_GAP));
    return map;
  }, [departs]);

  const nodes = useMemo(() => {
    const perDepartCounter = new Map<string, number>();
    const out: DisplayNode[] = [];

    const pushPosteTree = (poste: Poste, depth = 0, parentX?: number, forcedDepart?: string | null) => {
      const depart = forcedDepart ?? poste.depart ?? null;
      const laneIndex = laneMap.get(depart || "") ?? LANE_Y;
      const count = perDepartCounter.get(depart || "__none") ?? 0;
      const x = typeof parentX === "number" ? parentX + X_STEP * 0.85 : START_X + count * X_STEP;
      const y = laneIndex + depth * ANTENNA_DROP;

      if (typeof parentX !== "number") {
        perDepartCounter.set(depart || "__none", count + 1);
      }

      out.push({
        id: poste.id,
        kind: "poste",
        depart,
        x,
        y,
        label: truncate(poste.nom || poste.numero || poste.id, 16),
        sublabel: poste.numero || "",
        meta: poste.puissance_kva ? `${fmtNum(poste.puissance_kva)} kVA` : typeBlocLabel(poste.type_bloc),
        color: safeColor(
          departs.find((d) => d.depart === depart)?.couleur || poste.depart_couleur || "#2bb3c0",
        ),
        isAntenna: depth > 0,
        data: poste,
      });

      const children = [...(childrenByParent.get(poste.id) || [])].sort((a, b) => (a.x || 0) - (b.x || 0));
      children.forEach((child, idx) => {
        pushPosteTree(child, depth + 1, x + (idx + 1) * (X_STEP * 0.55), depart);
      });
    };

    departs.forEach((d) => {
      const postesDepart = rootPostes
        .filter((p) => p.depart === d.depart)
        .sort((a, b) => (a.x || 0) - (b.x || 0));

      postesDepart.forEach((poste) => pushPosteTree(poste, 0, undefined, d.depart));

      const rm6Depart = rm6
        .filter((r) => r.depart === d.depart)
        .sort((a, b) => (a.x || 0) - (b.x || 0));

      rm6Depart.forEach((item) => {
        const index = perDepartCounter.get(d.depart || "__none") ?? 0;
        out.push({
          id: item.id,
          kind: "rm6",
          depart: d.depart,
          x: START_X + index * X_STEP,
          y: (laneMap.get(d.depart) ?? LANE_Y) - 28,
          label: truncate(item.nom || item.label_detecte || "RM6", 16),
          sublabel: item.commande || "RM6",
          meta: item.etat || "organe",
          color: safeColor(d.couleur),
          isAntenna: false,
          data: item,
        });
        perDepartCounter.set(d.depart || "__none", index + 1);
      });
    });

    return out.sort((a, b) => a.y - b.y || a.x - b.x);
  }, [childrenByParent, departs, laneMap, rm6, rootPostes]);

  const bounds = useMemo(() => {
    const maxX = Math.max(1320, ...nodes.map((n) => n.x + 180));
    const maxY = Math.max(420, ...nodes.map((n) => n.y + 140), LANE_Y + departs.length * LANE_GAP);
    return { width: maxX, height: maxY };
  }, [nodes, departs.length]);

  const selectedNode = useMemo(() => nodes.find((n) => n.id === selectedId) || null, [nodes, selectedId]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === "h") setTool("pan");
      if (e.key.toLowerCase() === "s") setTool("select");
      if (e.key.toLowerCase() === "e") setEditMode((v) => !v);
      if (e.key === "0") setTransform({ x: 0, y: 0, s: 1 });
      if (e.key.toLowerCase() === "f") fitAll();
      if (e.key === "Escape") onSelect(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [nodes]);

  function fitAll() {
    const host = wrapRef.current;
    if (!host) return;
    const pad = 80;
    const sx = (host.clientWidth - pad) / bounds.width;
    const sy = (host.clientHeight - pad) / bounds.height;
    const s = Math.max(0.35, Math.min(1.2, Math.min(sx, sy)));
    setTransform({ x: 26, y: 22, s });
  }

  useEffect(() => {
    fitAll();
  }, [bounds.width, bounds.height, posteSourceLabel]);

  // Listener "wheel" natif et non-passif : React attache onWheel en mode passif
  // par défaut, ce qui empêche preventDefault() de bloquer le scroll de la page
  // pendant qu'on zoome dans le schéma (cause du "la page me suit" + lenteur).
  useEffect(() => {
    const host = wrapRef.current;
    if (!host) return;

    function onNativeWheel(e: WheelEvent) {
      e.preventDefault();
      const rect = host!.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      setTransform((t) => {
        const nextScale = Math.max(0.25, Math.min(2.4, t.s * (e.deltaY > 0 ? 0.92 : 1.08)));
        const worldX = (mx - t.x) / t.s;
        const worldY = (my - t.y) / t.s;
        return {
          s: nextScale,
          x: mx - worldX * nextScale,
          y: my - worldY * nextScale,
        };
      });
    }

    host.addEventListener("wheel", onNativeWheel, { passive: false });
    return () => host.removeEventListener("wheel", onNativeWheel);
  }, []);

  function handlePointerDown(e: React.PointerEvent<Element>) {
    if (tool !== "pan") return;
    dragStartRef.current = { x: e.clientX, y: e.clientY, ox: transform.x, oy: transform.y };
    setDraggingCanvas(true);
  }

  function handlePointerMove(e: React.PointerEvent<HTMLDivElement>) {
    const dragState = dragStartRef.current;
    if (dragState && tool === "pan") {
      const dx = e.clientX - dragState.x;
      const dy = e.clientY - dragState.y;
      setTransform((t) => ({ ...t, x: dragState.ox + dx, y: dragState.oy + dy }));
    }

    if (nodeDragRef.current && editMode && onReorder) {
      const delta = (e.clientX - nodeDragRef.current.startClientX) / transform.s;
      const reordered = nodes
        .filter((n) => n.kind === "poste")
        .map((n) => ({
          id: n.id,
          x: n.id === nodeDragRef.current?.id ? Math.max(0, Math.round(nodeDragRef.current.startNodeX + delta)) : Math.round(n.x),
        }));
      setDragPosteId(nodeDragRef.current.id);
      onReorder(reordered);
      nodeDragRef.current = null;
      setTimeout(() => setDragPosteId(null), 120);
    }
  }

  function handlePointerUp() {
    dragStartRef.current = null;
    nodeDragRef.current = null;
    setDraggingCanvas(false);
  }

  const departureLines = useMemo(
    () =>
      departs.map((d, i) => ({
        ...d,
        y: laneMap.get(d.depart) ?? LANE_Y + i * LANE_GAP,
      })),
    [departs, laneMap],
  );

  return (
    <div
      ref={wrapRef}
      className="schema-stage"
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
    >
      <div className="schema-floating-tools no-print">
        <button className={`schema-tool ${tool === "pan" ? "active" : ""}`} onClick={() => setTool("pan")}>
          ✋
        </button>
        <button className={`schema-tool ${tool === "select" ? "active" : ""}`} onClick={() => setTool("select")}>
          ↗
        </button>
        <button className="schema-tool" onClick={() => setTransform((t) => ({ ...t, s: Math.min(2.4, t.s * 1.12) }))}>
          +
        </button>
        <button className="schema-tool" onClick={() => setTransform((t) => ({ ...t, s: Math.max(0.25, t.s * 0.9) }))}>
          −
        </button>
        <button className="schema-tool" onClick={fitAll}>
          F
        </button>
        <button className={`schema-tool ${editMode ? "active" : ""}`} onClick={() => setEditMode((v) => !v)}>
          E
        </button>
      </div>

      <div className="schema-left-legend no-print">
        <div style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: "0.08em", color: "#8ea4b5", marginBottom: 8 }}>
          Départs
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
          {departs.slice(0, 8).map((d) => (
            <div key={d.depart} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 11 }}>
              <span style={{ width: 10, height: 10, borderRadius: 3, background: safeColor(d.couleur), flexShrink: 0 }} />
              <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {d.libelle || d.depart}
              </span>
              <strong style={{ fontSize: 10, color: "#dbe7f0" }}>{fmtNum(d.puissance_kva)}</strong>
            </div>
          ))}
        </div>
      </div>

      <div className="schema-mini-map no-print">
        <div style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: "0.08em", color: "#8ea4b5", marginBottom: 8 }}>
          Vue réseau
        </div>
        <div className="mini-map-box">
          {departureLines.slice(0, 6).map((d, idx) => (
            <div
              key={d.depart}
              className="mini-map-line"
              style={{ top: 12 + idx * 9, borderColor: safeColor(d.couleur) }}
            />
          ))}
          <div className="mini-map-window" />
        </div>
      </div>

      <svg
        className="schema-svg dark"
        viewBox={`0 0 ${bounds.width} ${bounds.height}`}
        onPointerDown={handlePointerDown}
        style={{ cursor: tool === "pan" ? (draggingCanvas ? "grabbing" : "grab") : "default" }}
      >
        <g transform={`translate(${transform.x} ${transform.y}) scale(${transform.s})`}>
          <defs>
            <pattern id="grid-v4" width="32" height="32" patternUnits="userSpaceOnUse">
              <path d="M 32 0 L 0 0 0 32" fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth="1" />
            </pattern>
          </defs>

          <rect x={0} y={0} width={bounds.width} height={bounds.height} fill="url(#grid-v4)" />

          <text x={BUS_X - 42} y={48} fill="#e6edf2" fontSize={18} fontWeight={800}>
            {posteSourceLabel}
          </text>
          <text x={BUS_X - 42} y={68} fill="#8294a1" fontSize={11}>
            Schéma unifilaire HTA · lecture exploitation
          </text>

          <line x1={BUS_X} y1={88} x2={BUS_X} y2={bounds.height - 36} stroke="#7d8f98" strokeWidth={2.4} />

          {departureLines.map((d) => (
            <g key={`lane-${d.depart}`}>
              <line
                x1={BUS_X}
                y1={d.y}
                x2={bounds.width - 60}
                y2={d.y}
                stroke={safeColor(d.couleur)}
                strokeWidth={2}
                strokeDasharray="0"
              />
              <rect x={18} y={d.y - 17} width={142} height={34} rx={8} fill="#0b1317" stroke={safeColor(d.couleur)} strokeWidth={1.2} />
              <rect x={18} y={d.y - 17} width={8} height={34} rx={8} fill={safeColor(d.couleur)} />
              <text x={34} y={d.y - 2} fill="#ecf3f8" fontSize={12} fontWeight={700}>
                {truncate(d.libelle || d.depart, 18)}
              </text>
              <text x={34} y={d.y + 12} fill="#7f93a3" fontSize={10}>
                {fmtNum(d.puissance_kva)} kVA · {d.nb_postes} postes
              </text>
            </g>
          ))}

          <rect x={48} y={bounds.height - 94} width={160} height={42} rx={8} fill="#0b1317" stroke="#233741" />
          <text x={64} y={bounds.height - 76} fill="#7f93a3" fontSize={10} letterSpacing="0.06em">
            CUMUL TOTAL
          </text>
          <text x={64} y={bounds.height - 60} fill="#ecf3f8" fontSize={15} fontWeight={800}>
            {fmtNum(departs.reduce((acc, d) => acc + (d.puissance_kva || 0), 0))} kVA
          </text>

          {nodes.map((node) => {
            const selected = selectedId === node.id;
            const hovered = hoverId === node.id;
            const stroke = selected ? "#62d7ff" : hovered ? "#f7cb61" : node.color;
            const fill = node.kind === "poste" && regimeOf((node.data as Poste).type_bloc) === "AB" ? node.color : "#ffffff";

            return (
              <g key={node.id}>
                {node.depart && (
                  <line
                    x1={node.isAntenna ? node.x - 56 : BUS_X}
                    y1={node.isAntenna ? node.y - ANTENNA_DROP + 16 : node.y}
                    x2={node.x - NODE_R - 8}
                    y2={node.y}
                    stroke={node.isAntenna ? "#617580" : node.color}
                    strokeWidth={node.isAntenna ? 1.4 : 2}
                    strokeDasharray={node.isAntenna ? "4 5" : undefined}
                  />
                )}

                {node.kind === "poste" ? (
                  <g
                    onMouseEnter={() => setHoverId(node.id)}
                    onMouseLeave={() => setHoverId(null)}
                    onClick={() => tool === "select" && onSelect(node.id)}
                    onDoubleClick={() => isPoste(node) && onEdit(node.data)}
                    onPointerDown={(e) => {
                      if (!editMode || !onReorder || tool !== "select" || !isPoste(node)) return;
                      e.stopPropagation();
                      nodeDragRef.current = {
                        id: node.id,
                        startClientX: e.clientX,
                        startNodeX: node.x,
                      };
                    }}
                    style={{ cursor: tool === "select" ? "pointer" : "default" }}
                  >
                    {((node.data as Poste).type_bloc || "").startsWith("POSTEH61") || ((node.data as Poste).type_bloc || "").startsWith("POSTEPVCR") ? (
                      <circle cx={node.x} cy={node.y} r={NODE_R} fill={fill} stroke={stroke} strokeWidth={selected ? 3 : 2} />
                    ) : (
                      <rect x={node.x - NODE_R} y={node.y - NODE_R} width={NODE_R * 2} height={NODE_R * 2} rx={4} fill={fill} stroke={stroke} strokeWidth={selected ? 3 : 2} />
                    )}
                    {dragPosteId === node.id && (
                      <circle cx={node.x} cy={node.y} r={28} fill="none" stroke="#62d7ff" strokeWidth={1.5} strokeDasharray="4 4" />
                    )}
                  </g>
                ) : (
                  <g
                    onMouseEnter={() => setHoverId(node.id)}
                    onMouseLeave={() => setHoverId(null)}
                    onClick={() => tool === "select" && onSelect(node.id)}
                    style={{ cursor: tool === "select" ? "pointer" : "default" }}
                  >
                    <rect x={node.x - 14} y={node.y - 12} width={28} height={24} rx={5} fill="#0d1418" stroke={stroke} strokeWidth={2} />
                    <line x1={node.x - 7} y1={node.y - 6} x2={node.x - 7} y2={node.y + 6} stroke={stroke} />
                    <line x1={node.x} y1={node.y - 6} x2={node.x} y2={node.y + 6} stroke={stroke} />
                    <line x1={node.x + 7} y1={node.y - 6} x2={node.x + 7} y2={node.y + 6} stroke={stroke} />
                  </g>
                )}

                <text x={node.x + 24} y={node.y - 5} fill="#edf4f8" fontSize={11.5} fontWeight={700}>
                  {node.label}
                </text>
                <text x={node.x + 24} y={node.y + 10} fill="#95a7b4" fontSize={10.5}>
                  {node.sublabel}
                </text>
                <text x={node.x + 24} y={node.y + 24} fill="#718591" fontSize={10}>
                  {node.meta}
                </text>
              </g>
            );
          })}

          {pointsOuverture.map((p) => (
            <g key={p.id}>
              <circle cx={p.x} cy={p.y} r={4} fill={p.etat === "OUVERT" ? "#f7cb61" : "#4ed59a"} />
              <circle cx={p.x} cy={p.y} r={8} fill="none" stroke="rgba(255,255,255,0.15)" />
            </g>
          ))}
        </g>
      </svg>

      {selectedNode && (
        <div className="schema-detail-dark no-print">
          <div className="schema-detail-head">
            <div>
              <strong>{selectedNode.label}</strong>
              <div style={{ color: "#90a4b4", marginTop: 4, fontSize: 11.5 }}>{selectedNode.sublabel || selectedNode.kind.toUpperCase()}</div>
            </div>
            {isPoste(selectedNode) && (
              <button className="btn primary" onClick={() => onEdit(selectedNode.data)}>
                Modifier
              </button>
            )}
          </div>

          {isPoste(selectedNode) ? (
            <>
              <div className="schema-detail-grid">
                <DetailCell label="Type" value={typeBlocLabel(selectedNode.data.type_bloc)} />
                <DetailCell label="Régime" value={regimeOf(selectedNode.data.type_bloc)} />
                <DetailCell label="Puissance" value={selectedNode.data.puissance_kva ? `${fmtNum(selectedNode.data.puissance_kva)} kVA` : "—"} />
                <DetailCell label="Départ" value={selectedNode.data.depart || "—"} />
                <DetailCell label="ILD" value={selectedNode.data.ild ? ildLabel(selectedNode.data.ild_etat) : "Non équipé"} />
                <DetailCell label="OMT" value={selectedNode.data.omt ? "Oui" : "Non"} />
                <DetailCell label="Commune" value={selectedNode.data.commune || "—"} />
                <DetailCell label="Zone" value={zoneOfCommune(selectedNode.data.commune || "") || "—"} />
              </div>
              <div className="schema-detail-path">
                Couleur ILD :{" "}
                <span style={{ color: selectedNode.data.ild ? ildColor(selectedNode.data.ild_etat) : "#5c6b75" }}>
                  {selectedNode.data.ild ? ildLabel(selectedNode.data.ild_etat) : "Non équipé"}
                </span>
                {selectedNode.data.commentaire ? ` · ${selectedNode.data.commentaire}` : ""}
              </div>
            </>
          ) : isRM6(selectedNode) ? (
            <>
              <div className="schema-detail-grid">
                <DetailCell label="Commande" value={selectedNode.data.commande || "RM6"} />
                <DetailCell label="État" value={selectedNode.data.etat || "—"} />
                <DetailCell label="Départ" value={selectedNode.data.depart || "—"} />
                <DetailCell label="Nom" value={selectedNode.data.nom || selectedNode.data.label_detecte || "—"} />
              </div>
              <div className="schema-detail-path">Cellule métier placée sur l’axe du départ pour lecture exploitation.</div>
            </>
          ) : null}
        </div>
      )}
    </div>
  );
}
