import { useEffect, useMemo, useState } from "react";
import { api } from "../lib/api";
import { expandAntennaFamily } from "../lib/types";
import type {
  Anomalie,
  DepartCumul,
  DepartDrift,
  JonctionCandidate,
  Poste,
  PosteSourceKpi,
} from "../lib/types";
import { fmtNum, safeColor } from "../lib/format";
import { SchemaView } from "../components/SchemaView";
import { TableView } from "../components/TableView";
import { PosteModal } from "../components/PosteModal";
import { AnomaliesPanel } from "../components/AnomaliesPanel";
import { ImportExportPanel } from "../components/ImportExportPanel";
import { DriftPanel } from "../components/DriftPanel";
import { MapView } from "../components/MapView";

import { DepartOverview } from "../components/DepartOverview";

type Tab = "departs" | "schema" | "tableau" | "anomalies" | "derive" | "import" | "carte";

interface Props {
  posteSource: string;
  kpi: PosteSourceKpi | undefined;
  toast: (msg: string, kind?: "ok" | "warn" | "err") => void;
}

export function PosteSourcePage({ posteSource, kpi, toast }: Props) {
  const [tab, setTab] = useState<Tab>("departs");
  const [postes, setPostes] = useState<Poste[]>([]);
  const [departs, setDeparts] = useState<DepartCumul[]>([]);
  const [drift, setDrift] = useState<DepartDrift[]>([]);
  const [anomalies, setAnomalies] = useState<Anomalie[]>([]);
  const [jonctions, setJonctions] = useState<JonctionCandidate[]>([]);
  const [rm6, setRm6] = useState<any[]>([]);
  const [po, setPo] = useState<any[]>([]);
  const [fDep, setFDep] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [modalPoste, setModalPoste] = useState<Partial<Poste> | null>(null);

  async function reload() {
    const [p, d, dr, a, j, r, pts] = await Promise.all([
      api.postes({ poste_source: posteSource }),
      api.departs(posteSource),
      api.departsDrift(posteSource),
      api.anomalies(posteSource),
      api.jonctions(),
      api.rm6(posteSource),
      api.pointsOuverture(posteSource),
    ]);

    setPostes((p || []) as Poste[]);
    setDeparts((d || []) as DepartCumul[]);
    setDrift((dr || []) as DepartDrift[]);
    setAnomalies((a || []) as Anomalie[]);
    setJonctions(((j || []) as JonctionCandidate[]).filter((x) => x.postes_source.includes(posteSource)));
    setRm6(r || []);
    setPo(pts || []);
  }

  useEffect(() => {
    reload().catch((e) => toast(`Erreur de chargement : ${e.message}`, "err"));
  }, [posteSource]);

  const filtered = useMemo(() => {
    let rows = postes;
    const filterActive = !!fDep || !!search;

    if (fDep) rows = rows.filter((p) => p.depart === fDep);

    if (search) {
      const s = search.toLowerCase();
      rows = rows.filter(
        (p) =>
          (p.nom || "").toLowerCase().includes(s) ||
          (p.numero || "").toLowerCase().includes(s),
      );
    }

    if (filterActive) {
      const ids = expandAntennaFamily(new Set(rows.map((p) => p.id)), postes);
      return postes.filter((p) => ids.has(p.id));
    }

    return rows;
  }, [postes, fDep, search]);

  const anomalyIds = useMemo(() => new Set(anomalies.map((a) => a.poste_id)), [anomalies]);

  const filteredRm6 = useMemo(() => {
    if (fDep) return rm6.filter((r: any) => r.depart === fDep);
    if (!search) return rm6;
    const s = search.toLowerCase();
    return rm6.filter(
      (r: any) =>
        (r.nom || "").toLowerCase().includes(s) ||
        (r.label_detecte || "").toLowerCase().includes(s),
    );
  }, [rm6, fDep, search]);

  async function handleSave(payload: Partial<Poste>) {
    try {
      if (payload.id) {
        await api.updatePoste(payload.id, { ...payload, poste_source: posteSource });
        toast("Poste mis à jour", "ok");
      } else {
        await api.createPoste({ ...payload, poste_source: posteSource });
        toast("Poste ajouté", "ok");
      }
      setModalPoste(null);
      await reload();
    } catch (e) {
      toast(`Erreur : ${(e as Error).message}`, "err");
    }
  }

  async function handleDelete(p: Poste) {
    if (!window.confirm(`Supprimer le poste \"${p.nom || p.numero || p.id}\" ?`)) return;
    try {
      await api.deletePoste(p.id);
      toast("Poste supprimé", "warn");
      await reload();
    } catch (e) {
      toast(`Erreur : ${(e as Error).message}`, "err");
    }
  }

  async function handleImport(rows: Partial<Poste>[]) {
    try {
      for (const r of rows) {
        await api.createPoste({ ...r, poste_source: posteSource });
      }
      toast("Import terminé", "ok");
      await reload();
    } catch (e) {
      toast(`Erreur import : ${(e as Error).message}`, "err");
    }
  }

  function fixAnomaly(posteId: string) {
    const p = postes.find((x) => x.id === posteId);
    if (p) setModalPoste(p);
  }

  const visibleDepartCount = new Set(filtered.map((p) => p.depart).filter(Boolean)).size;

  return (
    <div className="content">
      <section className="kpi-bar">
        <div className="kpi-cell">
          <div className="label">Puissance installée</div>
          <div className="value">
            {fmtNum(kpi?.puissance_kva)}
            <span className="unit">kVA</span>
          </div>
        </div>
        <div className="kpi-cell">
          <div className="label">Postes</div>
          <div className="value">{kpi?.nb_postes ?? 0}</div>
        </div>
        <div className="kpi-cell">
          <div className="label">DP / AB</div>
          <div className="value">
            {kpi?.nb_dp ?? 0}
            <span className="unit">/ {kpi?.nb_ab ?? 0}</span>
          </div>
        </div>
        <div className="kpi-cell">
          <div className="label">Clients</div>
          <div className="value">{fmtNum(kpi?.nb_clients)}</div>
        </div>
        <div className={`kpi-cell ${anomalies.length ? "warn" : ""}`}>
          <div className="label">Anomalies</div>
          <div className="value">{anomalies.length}</div>
        </div>
      </section>

      <section className="filter-row no-print">
        <div className="view-tabs">
          {([
            ["departs", "Départs"],
            ["schema", "Schéma"],
            ["tableau", "Tableau"],
            ["carte", "Carte"],
            ["anomalies", "Anomalies"],
            ["derive", "Dérive"],
            ["import", "Import/Export"],
          ] as [Tab, string][]).map(([key, label]) => (
            <button
              key={key}
              className={`view-tab ${tab === key ? "active" : ""}`}
              onClick={() => setTab(key)}
            >
              {label}
            </button>
          ))}
        </div>

        {(tab === "schema" || tab === "tableau" || tab === "carte") && (
          <>
            <button className={`chip ${!fDep ? "active" : ""}`} onClick={() => setFDep(null)}>
              Tous
              <span className="n">{departs.length}</span>
            </button>
            {departs.map((d) => {
              const active = fDep === d.depart;
              return (
                <button
                  key={d.depart}
                  className={`chip ${active ? "active" : ""}`}
                  onClick={() => setFDep((f) => (f === d.depart ? null : d.depart))}
                  style={active ? { color: safeColor(d.color) } : undefined}
                >
                  <span className="dot" style={{ background: safeColor(d.color) }} />
                  {d.libelle || d.depart}
                  <span className="n">{d.nb_postes}</span>
                </button>
              );
            })}

            <input
              className="search-input"
              placeholder="Rechercher un poste, numéro, RM6..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </>
        )}

        {(tab === "tableau" || tab === "schema") && (
          <button className="btn primary" onClick={() => setModalPoste({ poste_source: posteSource })}>
            + Poste
          </button>
        )}

        {tab === "schema" && (
          <button className="btn" onClick={() => window.print()}>
            🖨 Imprimer (A3)
          </button>
        )}
      </section>

      {tab === "departs" && (
        <DepartOverview
          departs={departs}
          anomalies={anomalies}
          onSelectDepart={(dep) => {
            setFDep(dep);
            setTab("schema");
          }}
        />
      )}

      {tab === "schema" && (
        <div className="schema-shell">
          <div className="schema-bottom-grid">
            <div className="side-card">
              <div className="side-card-title">Contexte réseau</div>
              <div className="side-big">{kpi?.nom || posteSource}</div>
              <div className="side-sub">
                {visibleDepartCount} départs visibles · {filtered.length} postes affichés · {filteredRm6.length} RM6
              </div>
              <div className="legend-list">
                <div className="legend-item">
                  <span className="legend-swatch legend-swatch-ab" />
                  Arrivée / régime AB
                </div>
                <div className="legend-item">
                  <span className="legend-swatch legend-swatch-dp" />
                  Départ / régime DP
                </div>
                <div className="legend-item">
                  <span className="legend-dot legend-dot-teal" />
                  Poste sélectionné
                </div>
                <div className="legend-item">
                  <span className="legend-dot legend-dot-amber" />
                  Point à surveiller
                </div>
                <div className="legend-item">
                  <span className="legend-glyph">RM6</span>
                  Cellule ou organe de coupure
                </div>
                <div className="legend-item">
                  <span className="legend-line" />
                  Liaison / continuité départ
                </div>
              </div>
            </div>

            <div className="side-card">
              <div className="side-card-title">Départs suivis</div>
              <div className="side-list">
                {departs.slice(0, 6).map((d) => (
                  <button
                    key={d.depart}
                    className="side-item"
                    onClick={() => {
                      setTab("schema");
                      setFDep(d.depart);
                    }}
                  >
                    <span>{d.libelle || d.depart}</span>
                    <em>{fmtNum(d.puissance_kva)} kVA</em>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="schema-canvas-card panel">
            <SchemaView
              postes={filtered}
              departs={fDep ? departs.filter((d) => d.depart === fDep) : departs}
              rm6={filteredRm6}
              pointsOuverture={po}
              posteSourceLabel={kpi?.nom || posteSource}
              selectedId={selected}
              onSelect={setSelected}
              onEdit={(p) => setModalPoste(p)}
              onReorder={async (items) => {
                try {
                  if (!api.reorderPostes) return;
                  await api.reorderPostes(items);
                  toast("Ordre mis à jour", "ok");
                  await reload();
                } catch (e) {
                  toast(`Erreur : ${(e as Error).message}`, "err");
                }
              }}
              onUpdateRm6={async (id, data) => {
                try {
                  if (!api.updateRm6) return;
                  await api.updateRm6(id, data);
                  toast("RM6 mis à jour", "ok");
                  await reload();
                } catch (e) {
                  toast(`Erreur : ${(e as Error).message}`, "err");
                }
              }}
            />
          </div>
        </div>
      )}

      {tab === "tableau" && (
        <div className="panel">
          <div className="panel-head">
            <span>{filtered.length} postes affichés</span>
            <span className="muted">Vue édition / tri métier</span>
          </div>
          <TableView
            postes={filtered}
            anomalyIds={anomalyIds}
            onRowClick={(p: Poste) => setModalPoste(p)}
            onDelete={handleDelete}
          />
        </div>
      )}

      {tab === "carte" && (
        <div className="panel">
          <div className="panel-head">
            <span>Carte métier</span>
            <span className="muted">Projection postes / départs</span>
          </div>
          <MapView postes={filtered} departs={departs} selectedId={selected} onSelect={setSelected} />
        </div>
      )}

      {tab === "anomalies" && (
        <div className="panel">
          <div className="panel-head">
            <span>{anomalies.length} anomalies détectées</span>
            <span className="muted">Contrôles de cohérence réseau</span>
          </div>
          <AnomaliesPanel anomalies={anomalies} onFix={fixAnomaly} />
        </div>
      )}

      {tab === "derive" && (
        <div className="panel">
          <div className="panel-head">
            <span>{drift.length} départs en dérive</span>
            <span className="muted">Écarts référentiel / calcul</span>
          </div>
          <DriftPanel drift={drift} jonctions={jonctions} />
        </div>
      )}

      {tab === "import" && (
        <div className="panel">
          <div className="panel-head">
            <span>Import / export</span>
            <span className="muted">Flux de maintenance base HTA</span>
          </div>
          <ImportExportPanel postes={postes} posteSource={posteSource} onImport={handleImport} />
        </div>
      )}

      {modalPoste && (
        <PosteModal
          poste={modalPoste as Poste}
          title={modalPoste.id ? `Modifier ${modalPoste.nom || modalPoste.numero || "poste"}` : "Nouveau poste"}
          onClose={() => setModalPoste(null)}
          onSave={handleSave}
        />
      )}
    </div>
  );
}
