import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { DepartCumul, Poste } from "../lib/types";
import {
  fmtNum,
  ildLabel,
  regimeOf,
  safeColor,
  typeBlocLabel,
} from "../lib/format";
import { zoneOfCommune } from "../lib/types";

/* ================================================================
   Types
   ================================================================ */

interface RM6 {
  id: string;
  depart: string | null;
  x: number;
  y?: number;
  nom: string | null;
  label_detecte: string | null;
  commande: string | null;
  a_verifier?: boolean;
  etat?: string | null;
}

interface TopoNode {
  poste_id: string;
  depart: string;
  parent_poste_id: string | null;
  ordre_principal: number | null;
  niveau_branche: number;
  rang_branche: number | null;
  nature_lien: string;
  extremite_reseau: boolean;
  bout_bouclage: boolean;
}

interface Props {
  postes: Poste[];
  departs: DepartCumul[];
  rm6: RM6[];
  pointsOuverture: { id: string; x: number; y: number; etat: string }[];
  posteSourceLabel: string;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onEdit: (poste: Poste) => void;
  onReorder?: (items: { id: string; x: number }[]) => void;
  onUpdateRm6?: (id: string, data: Record<string, unknown>) => void;
  topologie?: TopoNode[];
}

type ToolMode = "pan" | "select";

type LayoutNode = {
  id: string;
  kind: "poste" | "rm6";
  depart: string | null;
  x: number;
  y: number;
  label: string;
  sublabel: string;
  meta: string;
  color: string;
  isAntenna: boolean;
  isBouclage: boolean;
  parentId: string | null;
  parentX: number | null;
  parentY: number | null;
  data: Poste | RM6;
};

/* ================================================================
   Constants
   ================================================================ */

const BUS_X = 190;
const START_X = 350;
const X_STEP = 140;
const LANE_Y = 120;
const LANE_GAP = 220;
const BRANCH_DROP = 80;
const NODE_R = 16;

function truncate(value: string | null | undefined, max = 14) {
  if (!value) return "";
  return value.length > max ? `${value.slice(0, max - 1)}…` : value;
}

function isPoste(node: LayoutNode): node is LayoutNode & { data: Poste } {
  return node.kind === "poste";
}

function isRM6(node: LayoutNode): node is LayoutNode & { data: RM6 } {
  return node.kind === "rm6";
}

function DetailCell({
  label,
  value,
}: {
  label: string;
  value: string | number | null | undefined;
}) {
  return (
    <div>
      <div
        style={{
          fontSize: 10,
          color: "#7f93a3",
          textTransform: "uppercase",
          letterSpacing: "0.05em",
        }}
      >
        {label}
      </div>
      <div style={{ fontSize: 12, fontWeight: 700, marginTop: 2 }}>
        {value || "—"}
      </div>
    </div>
  );
}

/* ================================================================
   Tree Layout Engine
   ================================================================ */

function buildTreeLayout(
  postes: Poste[],
  departs: DepartCumul[],
  rm6: RM6[],
  topologie: TopoNode[] | undefined,
): LayoutNode[] {
  const posteById = new Map(postes.map((p) => [p.id, p]));
  const out: LayoutNode[] = [];

  // Lane Y positions per depart
  const laneMap = new Map<string, number>();
  departs.forEach((d, i) => laneMap.set(d.depart, LANE_Y + i * LANE_GAP));

  if (topologie && topologie.length > 0) {
    // === TOPOLOGY-DRIVEN LAYOUT ===
    // Group topology nodes by depart
    const topoByDepart = new Map<string, TopoNode[]>();
    topologie.forEach((t) => {
      if (!topoByDepart.has(t.depart)) topoByDepart.set(t.depart, []);
      topoByDepart.get(t.depart)!.push(t);
    });

    for (const [dep, topoNodes] of topoByDepart) {
      const depInfo = departs.find((d) => d.depart === dep);
      const color = safeColor(depInfo?.couleur);
      const baseY = laneMap.get(dep) ?? LANE_Y;

      // Separate trunk nodes and branch nodes
      const trunkNodes = topoNodes
        .filter(
          (t) => t.nature_lien === "TRONC" || t.nature_lien === "BOUCLAGE",
        )
        .filter((t) => t.parent_poste_id === null)
        .sort(
          (a, b) => (a.ordre_principal ?? 999) - (b.ordre_principal ?? 999),
        );

      const branchNodes = topoNodes.filter(
        (t) => t.nature_lien === "ANTENNE" || t.parent_poste_id !== null,
      );

      // Index enfants -> parent (sert au calcul d'emprise ET au placement)
      const childrenByParentId = new Map<string, TopoNode[]>();
      branchNodes.forEach((b) => {
        if (!b.parent_poste_id) return;
        if (!childrenByParentId.has(b.parent_poste_id))
          childrenByParentId.set(b.parent_poste_id, []);
        childrenByParentId.get(b.parent_poste_id)!.push(b);
      });

      // Largeur pleine par rang de branche : il faut au moins ça pour que le
      // libellé (texte) d'un poste ne chevauche pas le bloc du suivant.
      const BRANCH_OFFSET = X_STEP;

      // Emprise horizontale max du sous-arbre de branches d'un nœud, pour
      // savoir de combien décaler le prochain poste du tronc et éviter que
      // les branches d'un poste recouvrent le poste suivant du tronc.
      const reachCache = new Map<string, number>();
      const branchReach = (nodeId: string): number => {
        if (reachCache.has(nodeId)) return reachCache.get(nodeId)!;
        const children = (childrenByParentId.get(nodeId) || [])
          .slice()
          .sort((a, b) => (a.rang_branche ?? 999) - (b.rang_branche ?? 999));
        let max = 0;
        children.forEach((child, idx) => {
          const r = (idx + 1) * BRANCH_OFFSET + branchReach(child.poste_id);
          if (r > max) max = r;
        });
        reachCache.set(nodeId, max);
        return max;
      };

      // Place trunk nodes along the lane, en réservant assez de place pour
      // les branches de chaque poste avant de placer le suivant.
      const placedPositions = new Map<string, { x: number; y: number }>();
      let trunkX = START_X;
      trunkNodes.forEach((t) => {
        const poste = posteById.get(t.poste_id);
        if (!poste) return;
        placedPositions.set(t.poste_id, { x: trunkX, y: baseY });
        out.push({
          id: poste.id,
          kind: "poste",
          depart: dep,
          x: trunkX,
          y: baseY,
          label: truncate(poste.nom || poste.numero || poste.id, 16),
          sublabel: poste.numero || "",
          meta: poste.puissance_kva
            ? `${fmtNum(poste.puissance_kva)} kVA`
            : typeBlocLabel(poste.type_bloc),
          color,
          isAntenna: false,
          isBouclage: t.bout_bouclage,
          parentId: null,
          parentX: null,
          parentY: null,
          data: poste,
        });
        const reach = branchReach(t.poste_id);
        trunkX += Math.max(X_STEP, reach + 70);
      });

      // Place branch nodes recursively. La hauteur Y ne descend d'un cran que
      // sur une vraie bifurcation (plusieurs enfants pour un même parent) ;
      // une simple continuation de chaîne (1 seul enfant, ex: une longue
      // antenne CONVALESCENCE → SENAT → BAOBAB → ...) reste à la même
      // hauteur et avance seulement en X — sinon une longue antenne finit
      // par traverser la voie des départs suivants.
      const placeBranch = (parentId: string, depth: number) => {
        const children = (childrenByParentId.get(parentId) || [])
          .slice()
          .sort((a, b) => (a.rang_branche ?? 999) - (b.rang_branche ?? 999));

        const parentPos = placedPositions.get(parentId);
        if (!parentPos) return;

        const isFork = children.length > 1;

        children.forEach((child, idx) => {
          const poste = posteById.get(child.poste_id);
          if (!poste) return;

          const cx = parentPos.x + (idx + 1) * BRANCH_OFFSET;
          const cy = isFork
            ? baseY + depth * BRANCH_DROP + idx * (BRANCH_DROP * 0.5)
            : parentPos.y;
          const nextDepth = isFork ? depth + 1 : depth;

          placedPositions.set(child.poste_id, { x: cx, y: cy });

          out.push({
            id: poste.id,
            kind: "poste",
            depart: dep,
            x: cx,
            y: cy,
            label: truncate(poste.nom || poste.numero || poste.id, 16),
            sublabel: poste.numero || "",
            meta: poste.puissance_kva
              ? `${fmtNum(poste.puissance_kva)} kVA`
              : typeBlocLabel(poste.type_bloc),
            color,
            isAntenna: true,
            isBouclage: child.bout_bouclage,
            parentId,
            parentX: parentPos.x,
            parentY: parentPos.y,
            data: poste,
          });

          // Recurse for deeper branches
          placeBranch(child.poste_id, nextDepth);
        });
      };

      // Place branches from each trunk node
      trunkNodes.forEach((t) => placeBranch(t.poste_id, 1));

      // Branches dont le parent a été placé après coup (rattachement tardif)
      branchNodes.forEach((b) => {
        if (
          !placedPositions.has(b.poste_id) &&
          b.parent_poste_id &&
          placedPositions.has(b.parent_poste_id)
        ) {
          const poste = posteById.get(b.poste_id);
          if (!poste) return;
          const parentPos = placedPositions.get(b.parent_poste_id)!;
          const cx = parentPos.x + (b.rang_branche ?? 1) * BRANCH_OFFSET;
          const cy = parentPos.y + BRANCH_DROP;
          placedPositions.set(b.poste_id, { x: cx, y: cy });

          out.push({
            id: poste.id,
            kind: "poste",
            depart: dep,
            x: cx,
            y: cy,
            label: truncate(poste.nom || poste.numero || poste.id, 16),
            sublabel: poste.numero || "",
            meta: poste.puissance_kva
              ? `${fmtNum(poste.puissance_kva)} kVA`
              : typeBlocLabel(poste.type_bloc),
            color,
            isAntenna: true,
            isBouclage: b.bout_bouclage,
            parentId: b.parent_poste_id,
            parentX: parentPos.x,
            parentY: parentPos.y,
            data: poste,
          });
        }
      });

      // Update trunk X for next depart lane width calc
      const maxBranchX = Math.max(
        trunkX,
        ...Array.from(placedPositions.values()).map((p) => p.x),
      );

      // Place RM6 for this depart
      const rm6Dep = rm6
        .filter((r) => r.depart === dep)
        .sort((a, b) => (a.x || 0) - (b.x || 0));
      rm6Dep.forEach((item, idx) => {
        const rx = maxBranchX + idx * X_STEP;
        out.push({
          id: item.id,
          kind: "rm6",
          depart: dep,
          x: rx,
          y: baseY - 28,
          label: truncate(item.nom || item.label_detecte || "RM6", 16),
          sublabel: item.commande || "RM6",
          meta: item.etat || "organe",
          color,
          isAntenna: false,
          isBouclage: false,
          parentId: null,
          parentX: null,
          parentY: null,
          data: item,
        });
      });
    }

    // Handle postes not in topology (orphans)
    const topoPosteIds = new Set(topologie.map((t) => t.poste_id));
    const orphans = postes.filter((p) => !topoPosteIds.has(p.id) && p.depart);
    if (orphans.length > 0) {
      // Place orphans in their depart lane, after topology-placed nodes
      const orphansByDepart = new Map<string, Poste[]>();
      orphans.forEach((p) => {
        if (!p.depart) return;
        if (!orphansByDepart.has(p.depart)) orphansByDepart.set(p.depart, []);
        orphansByDepart.get(p.depart)!.push(p);
      });

      for (const [dep, orphanPostes] of orphansByDepart) {
        const depInfo = departs.find((d) => d.depart === dep);
        const color = safeColor(depInfo?.couleur);
        const baseY = laneMap.get(dep) ?? LANE_Y;
        const existingMaxX = Math.max(
          START_X,
          ...out.filter((n) => n.depart === dep).map((n) => n.x),
        );

        orphanPostes
          .sort((a, b) => (a.x || 0) - (b.x || 0))
          .forEach((poste, idx) => {
            const ox = existingMaxX + (idx + 1) * X_STEP;
            out.push({
              id: poste.id,
              kind: "poste",
              depart: dep,
              x: ox,
              y: baseY,
              label: truncate(poste.nom || poste.numero || poste.id, 16),
              sublabel: poste.numero || "",
              meta: poste.puissance_kva
                ? `${fmtNum(poste.puissance_kva)} kVA`
                : typeBlocLabel(poste.type_bloc),
              color: safeColor(color + "88"),
              isAntenna: false,
              isBouclage: false,
              parentId: null,
              parentX: null,
              parentY: null,
              data: poste,
            });
          });
      }
    }
  } else {
    // === FALLBACK: Original layout (antenne_de based) ===
    const childrenByParent = new Map<string, Poste[]>();
    postes.forEach((p) => {
      if (!p.antenne_de || p.antenne_de === p.id) return;
      if (!postes.some((x) => x.id === p.antenne_de)) return;
      if (!childrenByParent.has(p.antenne_de))
        childrenByParent.set(p.antenne_de, []);
      childrenByParent.get(p.antenne_de)!.push(p);
    });

    const rootPostes = postes.filter(
      (p) =>
        !p.antenne_de ||
        p.antenne_de === p.id ||
        !postes.some((x) => x.id === p.antenne_de),
    );

    const perDepartCounter = new Map<string, number>();

    const pushPosteTree = (
      poste: Poste,
      depth = 0,
      parentX?: number,
      parentY?: number,
      forcedDepart?: string | null,
    ) => {
      const dep = forcedDepart ?? poste.depart ?? null;
      const laneY = laneMap.get(dep || "") ?? LANE_Y;
      const count = perDepartCounter.get(dep || "__none") ?? 0;
      const x =
        typeof parentX === "number"
          ? parentX + X_STEP * 0.85
          : START_X + count * X_STEP;
      const y = laneY + depth * BRANCH_DROP;

      if (typeof parentX !== "number") {
        perDepartCounter.set(dep || "__none", count + 1);
      }

      out.push({
        id: poste.id,
        kind: "poste",
        depart: dep,
        x,
        y,
        label: truncate(poste.nom || poste.numero || poste.id, 16),
        sublabel: poste.numero || "",
        meta: poste.puissance_kva
          ? `${fmtNum(poste.puissance_kva)} kVA`
          : typeBlocLabel(poste.type_bloc),
        color: safeColor(
          departs.find((d) => d.depart === dep)?.couleur ||
            poste.depart_couleur ||
            "#2bb3c0",
        ),
        isAntenna: depth > 0,
        isBouclage: false,
        parentId: depth > 0 && typeof parentX === "number" ? null : null,
        parentX: depth > 0 ? (parentX ?? null) : null,
        parentY: depth > 0 ? (parentY ?? null) : null,
        data: poste,
      });

      const children = [...(childrenByParent.get(poste.id) || [])].sort(
        (a, b) => (a.x || 0) - (b.x || 0),
      );
      children.forEach((child, idx) => {
        pushPosteTree(
          child,
          depth + 1,
          x + (idx + 1) * (X_STEP * 0.55),
          y,
          dep,
        );
      });
    };

    departs.forEach((d) => {
      const postesDepart = rootPostes
        .filter((p) => p.depart === d.depart)
        .sort((a, b) => (a.x || 0) - (b.x || 0));

      postesDepart.forEach((poste) =>
        pushPosteTree(poste, 0, undefined, undefined, d.depart),
      );

      const rm6Dep = rm6
        .filter((r) => r.depart === d.depart)
        .sort((a, b) => (a.x || 0) - (b.x || 0));
      rm6Dep.forEach((item) => {
        const index = perDepartCounter.get(d.depart || "__none") ?? 0;
        out.push({
          id: item.id,
          kind: "rm6",
          depart: d.depart,
          x: START_X + index * X_STEP,
          y: (laneMap.get(d.depart) ?? LANE_Y) - 28,
          label: truncate(item.nom || item.label_detecte || "RM6", 16),
          sublabel: item.commande || "RM6",
          meta: item.etat || "organe",
          color: safeColor(d.couleur),
          isAntenna: false,
          isBouclage: false,
          parentId: null,
          parentX: null,
          parentY: null,
          data: item,
        });
        perDepartCounter.set(d.depart || "__none", index + 1);
      });
    });
  }

  // Dedup par id (un poste ne peut apparaître qu'une fois)
  const seen = new Set<string>();
  const deduped = out.filter((n) => {
    if (seen.has(n.id)) return false;
    seen.add(n.id);
    return true;
  });

  return deduped.sort((a, b) => a.y - b.y || a.x - b.x);
}

/* ================================================================
   Component
   ================================================================ */

export function SchemaView({
  postes,
  departs,
  rm6,
  pointsOuverture,
  posteSourceLabel,
  selectedId,
  onSelect,
  onEdit,
  onReorder,
  onUpdateRm6,
  topologie,
}: Props) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const gRef = useRef<SVGGElement | null>(null);
  const [tool, setTool] = useState<ToolMode>("pan");
  const [editMode, setEditMode] = useState(false);

  // Transform via ref — 0 re-render pendant pan/zoom
  const tRef = useRef({ x: 0, y: 0, s: 1 });
  const rafRef = useRef(0);
  const applyT = () => {
    const g = gRef.current;
    if (!g) return;
    const { x, y, s } = tRef.current;
    g.setAttribute("transform", `translate(${x} ${y}) scale(${s})`);
  };
  const dragStart = useRef<{
    x: number;
    y: number;
    ox: number;
    oy: number;
  } | null>(null);

  const nodes = useMemo(
    () => buildTreeLayout(postes, departs, rm6, topologie),
    [postes, departs, rm6, topologie],
  );
  const bounds = useMemo(() => {
    const maxX = Math.max(1320, ...nodes.map((n) => n.x + 180));
    const maxY = Math.max(
      420,
      ...nodes.map((n) => n.y + 140),
      LANE_Y + departs.length * LANE_GAP,
    );
    return { width: maxX, height: maxY };
  }, [nodes, departs.length]);
  const selectedNode = useMemo(
    () => nodes.find((n) => n.id === selectedId) || null,
    [nodes, selectedId],
  );

  const fitAll = useCallback(() => {
    const host = wrapRef.current;
    if (!host) return;
    const pad = 80;
    const sx = (host.clientWidth - pad) / bounds.width;
    const sy = (host.clientHeight - pad) / bounds.height;
    tRef.current = {
      x: 26,
      y: 22,
      s: Math.max(0.3, Math.min(1.2, Math.min(sx, sy))),
    };
    applyT();
  }, [bounds.width, bounds.height]);

  useEffect(() => {
    fitAll();
  }, [fitAll, posteSourceLabel]);

  // Keyboard
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === "INPUT") return;
      const k = e.key.toLowerCase();
      if (k === "h") setTool("pan");
      if (k === "s") setTool("select");
      if (k === "e") setEditMode((v) => !v);
      if (k === "f") fitAll();
      if (e.key === "0") {
        tRef.current = { x: 0, y: 0, s: 1 };
        applyT();
      }
      if (e.key === "Escape") onSelect(null);
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [fitAll, onSelect]);

  // Wheel zoom — ref only, no setState
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const fn = (e: WheelEvent) => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      const mx = e.clientX - r.left,
        my = e.clientY - r.top;
      const t = tRef.current;
      const ns = Math.max(
        0.2,
        Math.min(2.5, t.s * (e.deltaY > 0 ? 0.92 : 1.08)),
      );
      const wx = (mx - t.x) / t.s,
        wy = (my - t.y) / t.s;
      tRef.current = { s: ns, x: mx - wx * ns, y: my - wy * ns };
      cancelAnimationFrame(rafRef.current);
      rafRef.current = requestAnimationFrame(applyT);
    };
    el.addEventListener("wheel", fn, { passive: false });
    return () => el.removeEventListener("wheel", fn);
  }, []);

  // Pan — native listeners, ref only, rAF
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const down = (e: PointerEvent) => {
      if (tool !== "pan") return;
      dragStart.current = {
        x: e.clientX,
        y: e.clientY,
        ox: tRef.current.x,
        oy: tRef.current.y,
      };
      el.setPointerCapture(e.pointerId);
      el.style.cursor = "grabbing";
    };
    const move = (e: PointerEvent) => {
      const d = dragStart.current;
      if (!d) return;
      tRef.current.x = d.ox + (e.clientX - d.x);
      tRef.current.y = d.oy + (e.clientY - d.y);
      cancelAnimationFrame(rafRef.current);
      rafRef.current = requestAnimationFrame(applyT);
    };
    const up = () => {
      dragStart.current = null;
      if (tool === "pan") el.style.cursor = "grab";
    };
    el.addEventListener("pointerdown", down);
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointerleave", up);
    return () => {
      el.removeEventListener("pointerdown", down);
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointerleave", up);
    };
  }, [tool]);

  const departureLines = useMemo(
    () => departs.map((d, i) => ({ ...d, y: LANE_Y + i * LANE_GAP })),
    [departs],
  );
  const hasTopology = topologie && topologie.length > 0;

  return (
    <div
      ref={wrapRef}
      className="schema-stage"
      style={{ cursor: tool === "pan" ? "grab" : "default" }}
    >
      {/* Toolbar */}
      <div className="schema-floating-tools no-print">
        <button
          className={`schema-tool ${tool === "pan" ? "active" : ""}`}
          onClick={() => setTool("pan")}
        >
          ✋
        </button>
        <button
          className={`schema-tool ${tool === "select" ? "active" : ""}`}
          onClick={() => setTool("select")}
        >
          ↗
        </button>
        <button
          className="schema-tool"
          onClick={() => {
            tRef.current.s = Math.min(2.5, tRef.current.s * 1.15);
            applyT();
          }}
        >
          +
        </button>
        <button
          className="schema-tool"
          onClick={() => {
            tRef.current.s = Math.max(0.2, tRef.current.s * 0.87);
            applyT();
          }}
        >
          −
        </button>
        <button className="schema-tool" onClick={fitAll}>
          F
        </button>
        <button
          className={`schema-tool ${editMode ? "active" : ""}`}
          onClick={() => setEditMode((v) => !v)}
        >
          E
        </button>
        {hasTopology && (
          <span
            style={{
              fontSize: 9,
              color: "#4ed59a",
              padding: "0 8px",
              letterSpacing: ".06em",
              textTransform: "uppercase",
            }}
          >
            SCADA
          </span>
        )}
      </div>

      {/* SVG */}
      <svg
        className="schema-svg dark"
        viewBox={`0 0 ${bounds.width} ${bounds.height}`}
      >
        <defs>
          <pattern
            id="grid-v4"
            width="32"
            height="32"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 32 0 L 0 0 0 32"
              fill="none"
              stroke="rgba(255,255,255,0.03)"
              strokeWidth="1"
            />
          </pattern>
        </defs>
        <g ref={gRef}>
          <rect
            x={0}
            y={0}
            width={bounds.width}
            height={bounds.height}
            fill="url(#grid-v4)"
          />
          <text
            x={BUS_X - 42}
            y={48}
            fill="#e6edf2"
            fontSize={18}
            fontWeight={800}
          >
            {posteSourceLabel}
          </text>
          <text x={BUS_X - 42} y={68} fill="#8294a1" fontSize={11}>
            {hasTopology ? "Topologie SCADA" : "Lecture exploitation"}
          </text>
          <line
            x1={BUS_X}
            y1={88}
            x2={BUS_X}
            y2={bounds.height - 36}
            stroke="#7d8f98"
            strokeWidth={2.4}
          />

          {/* Lanes */}
          {departureLines.map((d) => (
            <g key={`lane-${d.depart}`}>
              <line
                x1={BUS_X}
                y1={d.y}
                x2={bounds.width - 60}
                y2={d.y}
                stroke={safeColor(d.couleur)}
                strokeWidth={2}
              />
              <rect
                x={18}
                y={d.y - 17}
                width={142}
                height={34}
                rx={8}
                fill="#0b1317"
                stroke={safeColor(d.couleur)}
                strokeWidth={1.2}
              />
              <rect
                x={18}
                y={d.y - 17}
                width={8}
                height={34}
                rx={8}
                fill={safeColor(d.couleur)}
              />
              <text
                x={34}
                y={d.y - 2}
                fill="#ecf3f8"
                fontSize={12}
                fontWeight={700}
              >
                {truncate(d.libelle || d.depart, 18)}
              </text>
              <text x={34} y={d.y + 12} fill="#7f93a3" fontSize={10}>
                {fmtNum(d.puissance_kva)} kVA · {d.nb_postes}p
              </text>
            </g>
          ))}

          {/* Branch connections */}
          {nodes
            .filter(
              (n) => n.isAntenna && n.parentX != null && n.parentY != null,
            )
            .map((n, i) => (
              <g key={`br-${n.id}-${i}`} opacity={0.6}>
                <line
                  x1={n.parentX!}
                  y1={n.parentY!}
                  x2={n.parentX!}
                  y2={n.y}
                  stroke="#617580"
                  strokeWidth={1.2}
                  strokeDasharray="4 5"
                />
                <line
                  x1={n.parentX!}
                  y1={n.y}
                  x2={n.x - NODE_R - 6}
                  y2={n.y}
                  stroke="#617580"
                  strokeWidth={1.2}
                  strokeDasharray="4 5"
                />
              </g>
            ))}

          {/* Bouclage */}
          {nodes
            .filter((n) => n.isBouclage)
            .map((n) => (
              <circle
                key={`bl-${n.id}`}
                cx={n.x}
                cy={n.y}
                r={NODE_R + 5}
                fill="none"
                stroke="#f7cb61"
                strokeWidth={1.4}
                strokeDasharray="3 3"
              />
            ))}

          {/* Nodes — hover is CSS, click is React */}
          {nodes.map((node) => {
            const sel = selectedId === node.id;
            const c = sel ? "#62d7ff" : node.color;
            const f =
              node.kind === "poste" &&
              regimeOf((node.data as Poste).type_bloc) === "AB"
                ? node.color
                : "#fff";
            const isCircle =
              node.kind === "poste" &&
              (((node.data as Poste).type_bloc || "").startsWith("POSTEH61") ||
                ((node.data as Poste).type_bloc || "").startsWith("POSTEPVCR"));
            return (
              <g
                key={node.id}
                className="schema-node"
                onClick={(e) => {
                  e.stopPropagation();
                  console.log("CLICK NODE", node.id, node.kind);
                  onSelect(node.id);
                  if (isPoste(node)) {
                    console.log("OPEN EDIT", node.data);
                    onEdit(node.data);
                  }
                }}
                style={{ cursor: "pointer" }}
              >
                {node.kind === "poste" ? (
                  isCircle ? (
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={NODE_R}
                      fill={f}
                      stroke={c}
                      strokeWidth={sel ? 3 : 1.6}
                    />
                  ) : (
                    <rect
                      x={node.x - NODE_R}
                      y={node.y - NODE_R}
                      width={NODE_R * 2}
                      height={NODE_R * 2}
                      rx={4}
                      fill={f}
                      stroke={c}
                      strokeWidth={sel ? 3 : 1.6}
                    />
                  )
                ) : (
                  <rect
                    x={node.x - 14}
                    y={node.y - 12}
                    width={28}
                    height={24}
                    rx={5}
                    fill="#0d1418"
                    stroke={c}
                    strokeWidth={1.6}
                  />
                )}
                {node.kind === "poste" && (node.data as Poste).omt && (
                  <circle
                    cx={node.x + NODE_R - 2}
                    cy={node.y - NODE_R + 2}
                    r={4.5}
                    fill="#0d1418"
                    stroke="#62d7ff"
                    strokeWidth={1}
                  />
                )}
                <text
                  x={node.x + 22}
                  y={node.y - 3}
                  fill="#edf4f8"
                  fontSize={10.5}
                  fontWeight={700}
                >
                  {node.label}
                </text>
                <text
                  x={node.x + 22}
                  y={node.y + 9}
                  fill="#95a7b4"
                  fontSize={9.5}
                >
                  {node.sublabel}
                </text>
              </g>
            );
          })}

          {pointsOuverture.map((p) => (
            <circle
              key={`po-${p.id}`}
              cx={p.x}
              cy={p.y}
              r={4}
              fill={p.etat === "OUVERT" ? "#f7cb61" : "#4ed59a"}
            />
          ))}
        </g>
      </svg>

      {/* Detail panel */}
      {selectedNode && (
        <div className="schema-detail-dark no-print">
          <div className="schema-detail-head">
            <div>
              <strong>{selectedNode.label}</strong>
              <div style={{ color: "#90a4b4", marginTop: 4, fontSize: 11.5 }}>
                {selectedNode.sublabel}
              </div>
            </div>
            {isPoste(selectedNode) && (
              <button
                className="btn primary"
                onClick={() => onEdit(selectedNode.data)}
              >
                Modifier
              </button>
            )}
          </div>
          {isPoste(selectedNode) && (
            <div className="schema-detail-grid">
              <DetailCell
                label="Type"
                value={typeBlocLabel(selectedNode.data.type_bloc)}
              />
              <DetailCell
                label="Régime"
                value={regimeOf(selectedNode.data.type_bloc)}
              />
              <DetailCell
                label="Puissance"
                value={
                  selectedNode.data.puissance_kva
                    ? `${fmtNum(selectedNode.data.puissance_kva)} kVA`
                    : "—"
                }
              />
              <DetailCell
                label="Départ"
                value={selectedNode.data.depart || "—"}
              />
              <DetailCell
                label="ILD"
                value={
                  selectedNode.data.ild
                    ? ildLabel(selectedNode.data.ild_etat)
                    : "Non"
                }
              />
              <DetailCell
                label="OMT"
                value={selectedNode.data.omt ? "Oui" : "Non"}
              />
              <DetailCell
                label="Commune"
                value={selectedNode.data.commune || "—"}
              />
              <DetailCell
                label="Zone"
                value={zoneOfCommune(selectedNode.data.commune || "") || "—"}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
